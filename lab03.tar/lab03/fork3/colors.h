#define BLACK           "\e[0;0;30m"
#define RED             "\e[0;0;31m"
#define GREEN           "\e[0;0;32m"
#define YELLOW          "\e[0;0;33m"
#define BLUE            "\e[0;0;34m"
#define NO_COLOR        "\e[0m"

