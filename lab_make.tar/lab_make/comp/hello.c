#include<stdio.h>
#include "hello.h"

int main () {
 char *name;
 name = get_name();
 printf("Hello %s!!\n", name);

 return 0;
}
 

 
