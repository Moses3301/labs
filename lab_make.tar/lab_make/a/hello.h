
char* get_first();
char* get_last();
void greet(char *);
char* get_color();
void print_color(char* color, char* str);