#include<stdio.h>
#include<stdlib.h>
#include <unistd.h> 		// for fork, sleep etc.
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h> 
#include <fcntl.h>   
#include <string.h>

/*
ex#3: redirection WITH fork.
argv[1] - name of the file to replace stdout
argv[2] - name of the file to replace stdin

In this exercise, we want to parent process to fork.
Then, The parent processs calls write_messages which writes to stdout and stderr.
The child process calls write_messages which writes to the redirected files.

*/

void usage_err();
void do_child();

char* out_msg = "Hello Standard Output\n";
char* err_msg = "Hello Standard Error\n";

//------------------------------------------------
void write_messages()
{
  static int n = 1;
  char str[20];
  sprintf(str, "(%d pid=%d) ", n++, getpid());
  write(1, str, strlen(str));  
  write(1, out_msg, strlen(out_msg));
  write(2, str, strlen(str));  
  write(2, err_msg, strlen(err_msg));
}

//------------------------------------------------
int open_file(char* name)
{
	int fd;
	fd = open(name, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
	if (fd < 0)  // open failed
	{
		fprintf(stderr, "ERROR: open \"%s\" failed (%d). Exiting\n", name, fd);
		exit(2);
	}
	fprintf(stderr, "opened file %s, file descriptor is: %d\n",name, fd);
	return(fd);
}

//------------------------------------------------
int main(int argc, char* argv[])
{
  if (argc != 3) 
    usage_err(argc);
  
	write_messages();
  
  if (fork() == 0) { // child section
     
    // redirection here for the child only
    close(1);
    open_file(argv[1]);
    close(2);
    open_file(argv[2]);
    do_child();
    exit(0);
  }
	write_messages();
  wait(NULL);
  
	exit(0);
}

//------------------------------------------------
void do_child()
{
  fprintf(stdout, "pid=%d child process\n", getpid());
  fprintf(stderr, "pid=%d child process\n", getpid());
  write_messages();
  exit(0);
}

//------------------------------------------------
void usage_err(int count)
{
  fprintf(stderr, "Expecting two arguments and got %d arguments\n", --count);
  fprintf(stderr, " the arguments should be: name of output-file and name of error-file.\n");
  exit(1);
}
