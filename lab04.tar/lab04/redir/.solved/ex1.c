#include<stdio.h>
#include<stdlib.h>
#include <unistd.h> 		// for fork, sleep etc.
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h> 
#include <fcntl.h>   
#include <string.h>

/*
ex#1: redirection without fork.
argv[1] - name of the file to replace stdout
argv[2] - name of the file to replace stdin
*/

void usage_err();

char* out_msg = "Hello Standard Output\n";
char* err_msg = "Hello Standard Error\n";

//------------------------------------------------
void write_messages()
{
  static int n = 1;
  char str[20];
  sprintf(str, "(%d pid=%d) ", n++, getpid());
  write(1, str, strlen(str));  
  write(1, out_msg, strlen(out_msg));
  write(2, str, strlen(str));  
  write(2, err_msg, strlen(err_msg));
}

//------------------------------------------------
int open_file(char* name)
{
	int fd;
	fd = open(name, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
	if (fd < 0)  // open failed
	{
		fprintf(stderr, "ERROR: open \"%s\" failed (%d). Exiting\n", name, fd);
		exit(2);
	}
	fprintf(stderr, "opened file %s, file descriptor is: %d\n",name, fd);
	return(fd);
}

//------------------------------------------------
int main(int argc, char* argv[])
{
  if (argc != 3) 
    usage_err(argc);
  
	write_messages();
  
  int fd_out = open_file(argv[1]);
  int fd_err = open_file(argv[2]);
 
  //  do the redirection
  close(1);
  dup(fd_out);
  close(fd_out);

  close(2);
  dup(fd_err);
  close(fd_err);
  
  
  
  write_messages();
  
	exit(0);
}

//------------------------------------------------
void usage_err(int count)
{
  fprintf(stderr, "Expecting two arguments and got %d arguments\n", --count);
  fprintf(stderr, " the arguments should be: name of output-file and name of error-file.\n");
  exit(1);
}
