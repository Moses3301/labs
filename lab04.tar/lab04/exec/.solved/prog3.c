#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <string.h>

// **** prog3.c **** 
// Demonstrate how to work with command line arguments

char* my_argv[2];

//-----------------------------------------------
int main(int argc, char* argv[])
{
  
  // complete the following two lines: 
  char prog_name[20] = "hello_who";
  my_argv[0] = "hello_who";
  my_argv[1] = (char*) malloc(strlen(argv[1]) + 1);
  strcpy(my_argv[1], argv[1]);
  my_argv[2] = NULL;
  
  // printf("program: %s, pid = %d --> Going to run execve() ...\n", 
         // argv[0], getpid());

  execve(prog_name, my_argv, NULL);
  fprintf(stderr, "*** ERROR: *** EXEC of %s FAILED\n", prog_name);
  exit(1);
}


