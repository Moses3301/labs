#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <string.h>


char* my_argv[2];

//-----------------------------------------------
int main(int argc, char* argv[])
{
  
  // complete the following two lines: 
  //char prog_name[20] = ????;
  // my_argv[0] = "------"; // what if I change this to "kuku"? try it
  my_argv[1] = NULL;
  
  
  // setbuf(stdout, NULL);
  // setbuf(stdin, NULL);
  // setbuf(stderr, NULL);
  
  int pid;
  if ((pid = fork()) == 0)
  {
    execve(prog_name, my_argv, NULL);
    fprintf(stderr, "*** ERROR: *** EXEC of %s FAILED\n", prog_name);
    exit(1);
  } 
  printf("program: %s, pid = %d --> Just forked process %d ...\n", 
         argv[0], getpid(), pid);
  wait(NULL);
}


