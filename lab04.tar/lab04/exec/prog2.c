#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <string.h>

// **** prog2.c **** 
// Demonstrate that we don't need to fork() first, before we exec().
// What is going to be the output of this program?

char* my_argv[2];

//-----------------------------------------------
int main(int argc, char* argv[])
{
  
  // complete the following two lines: 
  char prog_name[20] = "hello";
  my_argv[0] = "hello";
  my_argv[1] = NULL;
  
  printf("program: %s, pid = %d --> Going to run execve() ...\n", 
         argv[0], getpid());

  int ret_val = execve(prog_name, my_argv, NULL);
  if (ret_val < 0) // does it make sense al all ??
  {
    fprintf(stderr, "*** ERROR: *** EXEC of %s FAILED\n", prog_name);
    exit(1);
  } 
  printf("EXEC done successfulhy !!\n");
  wait(NULL);   // Indeed??
  return 1;
}


